<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div id="bookly-tbs">
    <div class="board-backdrop in">
        <div class="well bookly-board">
            <div class="h4"><?php _e( 'License verification required', 'bookly' ) ?></div>
            <div class="bookly-board-body">
                <?php echo $board_body ?>
            </div>
        </div>
    </div>
</div>