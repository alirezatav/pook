<?php
namespace Bookly\Backend\Modules\Settings;

use Bookly\Lib;

/**
 * Class Components
 * @package Bookly\Backend\Modules\Support
 */
class Components extends Lib\Base\Components
{
    /**
     * Render collect stats notice and marks it as showed for every user
     */
    public function renderCollectStatsNotice()
    {

    }
}