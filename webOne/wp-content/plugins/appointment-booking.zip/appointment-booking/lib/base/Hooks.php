<?php
namespace Bookly\Lib\Base;

/**
 * Class Hooks
 * @package Bookly\Lib\Base
 * @deprecated
 */
abstract class Hooks
{
    /**
     * @deprecated
     */
    public static function getInstance()
    {
    }
}