

var app2 = angular.module('crudApp', ['ngJalaaliFlatDatepicker']);

app2.controller('crudController', function($scope, $http) {

    $scope.buttonName = "Add";

    $scope.displayUsers = function() {
        $http.get('select.php')
                .success(function(data) {
                    $scope.students = data;	    
                })
    }

    $scope.insertData = function() {
        if ($scope.name == null || $scope.email == null) {
            $scope.message_color = "red";
            $scope.message = "All fields are required.";
        } else {

            $http.post('insert.php', {
                'name': $scope.name, //ng-model of textbox name
                'email': $scope.email, //ng-model of textbox email
                'notes': $scope.notes, //ng-model of textbox notes
                'buttonName': $scope.buttonName, //ng-model of button
                'id': $scope.id //hidden id
            })
                    .success(function() {
                        $scope.message_color = "green";
                        $scope.message = "Success.";
                        $scope.name = null; //reset textbox values
                        $scope.email = null; //reset textbox values
                        $scope.notes = null; //reset textbox values
                        $scope.buttonName = "Add"; //Change textbox value to Add
                        $scope.displayUsers(); //Update the users table
                    })
                    .error(function() {
                        console.log("Error");
                    })

        }

    }

    $scope.updateData = function(id, name, email) {
        $scope.id = id;
        $scope.name = name;
        $scope.email = email;
        $scope.buttonName = "Update";
    }

    $scope.deleteData = function(id) {
        if (confirm("are you sure to Delete this Appointment ?"))
        {
            $http.post("delete.php", {'id': id})
                    .success(function() {
                        $scope.message_color = "blue";
                        $scope.message = "Data deleted.";
                        $scope.displayUsers();
                    })
                    .error(function() {
                        console.log("Error");
                    })
        }
        else
        {
            return false;
        }
    }
    $scope.reception = function(id) {
        if (confirm("are you sure to Reciept this Appointment ?")) {

            $http.post("reception.php", {'id': id})
                    .success(function() {
                        $scope.message_color = "green";
                        $scope.message = "user recepted.";
                        $scope.displayUsers();
						window.location.reload();
                    })
                    .error(function() {
                        console.log("Error");
                    })
        }
    }

	
	    $scope.print = function(id) {
        if (confirm("are you sure to Print this Appointment ?")) {
				
            
var draw_qrcode = function(text, typeNumber, errorCorrectionLevel) {
  document.write(create_qrcode(text, typeNumber, errorCorrectionLevel) );
};

var create_qrcode = function(text, typeNumber, errorCorrectionLevel, mode,
    mb) {

  qrcode.stringToBytes = qrcode.stringToBytesFuncs[mb];

  var qr = qrcode(typeNumber || 4, errorCorrectionLevel || 'M');
  qr.addData(text, mode);
  qr.make();

//  return qr.createTableTag();
//  return qr.createSvgTag();
  return qr.createImgTag();
};

var update_qrcode = function() {
  //var form = document.forms['qrForm'];
  var text = $scope.token = id;
  //form.elements['msg'].value.
    replace(/^[\s\u3000]+|[\s\u3000]+$/g, '');
  var t = '8';
  var e = 'Q';
  var m = 'Byte';
  var mb = 'UTF-8';
  document.getElementById('qr').innerHTML = create_qrcode(text, t, e, m, mb);
};

        }
    }


    
});

app2.filter('searchFilter',function($filter) {
        return function(items,searchfilter) {
             var isSearchFilterEmpty = true;
              angular.forEach(searchfilter, function(searchstring) {   
                  if(searchstring !=null && searchstring !=""){
                      isSearchFilterEmpty= false;
                  }
              });
        if(!isSearchFilterEmpty){
                var result = [];  
                angular.forEach(items, function(item) {  
                    var isFound = false;
                     angular.forEach(item, function(term,key) {                         
                         if(term != null &&  !isFound){
                             term = term.toString();
                             term = term.toLowerCase();
                                angular.forEach(searchfilter, function(searchstring) {      
                                    searchstring = searchstring.toLowerCase();
                                    if(searchstring !="" && term.indexOf(searchstring) !=-1 && !isFound){
                                       result.push(item);
                                        isFound = true;
                                    }
                                });
                         }
                            });
                       });
            return result;
        }else{
        return items;
        }
    }
});

(function() {

   app2.controller('mainController', ['$scope', mainController]);

    function mainController ($scope) {

        $scope.datepickerConfig = {
            allowFuture: false,
            dateFormat: 'jYYYY/jMM/jDD',
            gregorianDateFormat: 'YYYY/DD/MM',
            minDate: moment.utc('2008', 'YYYY')
        };
    }

})();