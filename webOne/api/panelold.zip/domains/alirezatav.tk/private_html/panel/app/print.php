<?php

include 'connect.php';

$data = json_decode(file_get_contents("php://input"));



$aid= $data->id;




$statement = $conn->prepare('
select a.id as id, c.name,c.email,c.phone,a.start_date ,a.end_date,s.status as sid
from wp_ab_customers c 
inner join wp_ab_customer_appointments ca 
    on c.id = ca.customer_id
right outer join wp_ab_appointments a
    on ca.appointment_id =a.id
left outer join appstatus s 
    on s.app_id=a.id


  ');
  $statement->execute(array());
while ($row = $statement->fetch()) {
    $date2 = new DateTime($row["start_date"]);
    $row["date"] = MtoJ($date2) . " " ;
    $row["start_time"] = my_getTime($date2);
    $date2 = new DateTime($row["end_date"]);
    if( $row["sid"] !='1' ){
            $row["sid"] = "در انتظار پذیرش";
			$row["btn"] = false;
	}
    else if( $row["sid"] = '1'){
            $row["sid"] = "انجام شد";
			$row["btn"] = true;}
    $data[] = $row;
}

print json_encode($data);