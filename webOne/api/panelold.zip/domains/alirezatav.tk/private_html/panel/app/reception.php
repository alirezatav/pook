<?php

include 'connect.php';

$data = json_decode(file_get_contents("php://input"));

$statement = $conn->prepare("INSERT INTO appstatus (app_id,status) VALUES (:id, true ) ");
$statement->execute(array(
	'id' => $data->id
));

