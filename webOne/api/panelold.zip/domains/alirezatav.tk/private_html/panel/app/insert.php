<?php

include 'connect.php';

$data = json_decode(file_get_contents("php://input"));

$buttonName = $data->buttonName;

if($buttonName == "Add")
{
	$statement = $conn->prepare("INSERT INTO wp_ab_customers (name,email) VALUES (:name, :email )");
	$statement->execute(array(
		'name' => $data->name,
		'email' => $data->email,
		
		
	));
    
	

}
elseif($buttonName == "Update")
{
	$statement = $conn->prepare("UPDATE wp_ab_customers SET name=:name, email=:email WHERE id=:id");
	$statement->execute(array(
		'name' => $data->name,
		'email' => $data->email,
		'id' => $data->id
	));
}