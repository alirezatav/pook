<?php

$username = 'alirezat_admin';
$password = 'alirezaT94';

try {
    $conn = new PDO('mysql:host=localhost;dbname=alirezat_POOK', $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);    
} catch(PDOException $e) {
    echo 'ERROR: ' . $e->getMessage();
}